
import './App.css';
import Home from './components/home/Home'
import 'bootstrap/dist/css/bootstrap.css'
function App() {
  return (
    <div className="App">
      <h1>hii</h1>
      <Home></Home>
    </div>
  );
}

export default App;

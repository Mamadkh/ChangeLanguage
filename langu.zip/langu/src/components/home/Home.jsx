import { useTranslation } from 'react-i18next'

export default function Home() {
    const { t, i18n } = useTranslation()
    function OnLanguageChanged(e) {
        i18n.changeLanguage(e.target.value)
    }
    return (
        <div dir={t('dir')} className="container col-4">
            <div>
                <select onChange={OnLanguageChanged} className="container">
                    <option value='en'>English</option>
                    <option value='fr'>French</option>
                    <option value='fa'>فارسی</option>
                </select>
            </div>
            <p>
                <div className='form-group'>
                    <label> {t('name')} </label>
                    <input className='form-control' />
                </div>
            </p>
            <p>
                <div className='form-group'>
                    <label> {t('family')} </label>
                    <input className='form-control' />
                </div>
            </p>
        </div>
    )
}